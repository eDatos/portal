function get_short_url(long_url, func)
{
    $.getJSON(
        "http://api.bitly.com/v3/shorten?callback=?", 
        { 
            "format": "json",
            "apiKey": "R_bc8722633743817b96ab25bd478fab26",
            "login": "dummytwitter2012",
            "longUrl": long_url
        },
        function(response)
        {
        	var returned_url;
        	
        	if(response.status_code == 200){
        		returned_url = response.data.url;
        	}else{
        		returned_url = long_url;
        	}       
        	
            func(returned_url);
        }
    );
}


function setHref(idLink, url, summary)
{
	var completeUrl = url;
	if(summary){
		completeUrl = url.replace("%SUMMARY%", summary);
	}
		
	$(idLink).attr('href', encodeURI(completeUrl));
}
