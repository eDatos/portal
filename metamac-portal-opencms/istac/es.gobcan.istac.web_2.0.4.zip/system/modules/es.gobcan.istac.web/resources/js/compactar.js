function shrinkHeader(id){
	document.getElementById(id).style.display = (document.getElementById(id).style.display == "none") ? "" : "none";
} 