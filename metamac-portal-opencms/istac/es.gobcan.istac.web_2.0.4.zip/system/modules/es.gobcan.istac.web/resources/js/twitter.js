/* Gets the users list as a parameter (comma separated) formatted to
 * call the twitter REST API.
 * Params:
 *    -maxFollowers: max followers to show.
 *    -ids: array of twitter identifiers.
 * Returns:
 *    string of comma separated ids to use in the twitter REST API as
 *    a parameter.
 */
function getUsersParam(maxFollowers, ids) {
	var url = "";
	var limit = maxFollowers;

	limit = limit < ids.length? limit: ids.length;

	for (i = 0; i < limit; i++) {
		url += ids[i];	
		if (i < limit - 1) {
			url += ",";
		}
	}

	return url;
}

/* Gets the html to show the followers.
 * Params:
 *    -usersInfo: twitter response containing user info.
 * Returns:
 *    html formated block of users info, each one a user photo
 *    linked to the twitter user URL.
 */
function getUsersInfoBlock(usersInfo) {
	var htmlUsersBlock = "";

	for (i = 0; i < usersInfo.length; i++) {
		var link = getTwitterUserLink(usersInfo[i]);
		var username = getTwitterUserName(usersInfo[i]);
		var userImageUrl = getUserImageUrl(usersInfo[i].screen_name);
		var htmlNode = getHtmlNodeForUser(username, link, userImageUrl);
		htmlUsersBlock += htmlNode;
	}

	return htmlUsersBlock == ""? "" : "<ul>" + htmlUsersBlock + "</ul>";
}

/* Gets user image URL.
 * Params:
 *    -screen_name: user twitter screen name.
 * Returns:
 *    URL to the profile image of the twitter "screen_name".
 */
function getUserImageUrl(screen_name) {
	var imageSize = "mini";
	var twitterImagesUrl = "http://api.twitter.com/1/users/profile_image?screen_name=" + screen_name + "&size=" + imageSize;

	return twitterImagesUrl;
}

/* Return a html node for the user.
 * Params:
 *    -username: username for the html element.
 *    -link: link to the username twitter profile.
 *    -userImageUrl: URL for the twitter user image.
 * Return:
 *    html li element for the user.
 */
function getHtmlNodeForUser(username, link, userImageUrl) {
	var htmlNode = "<li><a href=\"" + link + "\">" + "<img height=\"24\" width=\"24\" alt=\"" + username + "\" src=\"" + userImageUrl + "\" /></a></li>";
	return htmlNode;
}

/* Returns the twitter user name from the twitter user info REST API response.
 * Params:
 *    -userInfo: user information given by twitter REST API.
 * Returns:
 *    twitter user name.
 */
function getTwitterUserName(userInfo) {
	return userInfo.name;
}

/* Gets the twitter user link from a twitter user node REST API response.
 * Params:
 *    -userNode: user information object.
 * Returns:
 *    link to the twitter user page.
 */
function getTwitterUserLink(userNode) {
	var userLinkBase = "http://www.twitter.com/";

	return userLinkBase + userNode.screen_name;
}

/* Prints a list of twitter users as an image linked to the twitter user profile.
 * Params:
 *    -targetBlock: html block id where the mosaic will be created.
 *    -maxFollowers: max number of followers to show.
 *    -ids: identifiers of twitter followers.
 * Returns:
 *   nothing.
 */
function printMosaic(targetBlock, maxFollowers, ids) {
	var param = getUsersParam(maxFollowers, ids);
	if (param == "")
	  return true;
	$.getJSON("http://api.twitter.com/1/users/lookup.json?user_id=" + param + "&callback=?",
	          function(usersInfo) {
				 	 var htmlUsersBlock = "";
					 htmlUsersBlock = getUsersInfoBlock(usersInfo);

					 var twitterNode = document.getElementById(targetBlock);
					 twitterNode.innerHTML = htmlUsersBlock;

					 return true;
	          }
	         );
}

/* Prints a block of twitter followers.
 * Params:
 *    -twitterUser: twitter user whose followers are going to be shown.
 *    -targetBlock: html block id where the mosaic will be created.
 *    -maxFollowers: max number of followers to show.
 */
function printFollowersBlock(twitterUser, targetBlock, maxFollowers) {
	$.getJSON("http://api.twitter.com/1/followers/ids.json?screen_name=" + twitterUser + "&callback=?",
  	          function(data) {
		         printMosaic(targetBlock, maxFollowers, data.ids);
		         return true;
  	          });
}

//-------------------------------------------------------------------------
// Número de seguidores de twitter
function printFollowersNumber(twitterUser, targetBlock) {
	$.getJSON("http://api.twitter.com/1/users/show.json?screen_name=" + twitterUser + "&callback=?",
  	          function(data) {
		         printTotalFollowers(targetBlock, data.followers_count);
		         return true;
  	          });

}

/* Writes the number of followers of a user.
 * Params:
 * 	-targetBlock: html block id where the followers number will be written to.
 * 	-followersNumber: number of followers to print.
 */
function printTotalFollowers(targetBlock, followersNumber) {
	var twitterFollowersNumberNode = document.getElementById(targetBlock);
	twitterFollowersNumberNode.innerHTML = followersNumber;

	return true;
}

