function mostrar(id) {
	element = document.getElementById(id);
	element.style.display = 'block';
}

function ocultar(id) {
	element = document.getElementById(id);
	element.style.display = 'none';
}

function switchNormalRelated(checkboxId, normal, related) {
	normal = document.getElementById(normal);
	related = document.getElementById(related);
	checkElement = document.getElementById(checkboxId);

	if (checkElement.checked) {
			  normal.style.display = 'none';
			  related.style.display = 'block';
	}
	else {
  			  normal.style.display = 'block';
			  related.style.display = 'none';
	}

}

