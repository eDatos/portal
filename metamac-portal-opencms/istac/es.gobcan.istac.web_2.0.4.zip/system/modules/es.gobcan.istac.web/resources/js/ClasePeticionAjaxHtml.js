/* NombreVariable es el nombre de la variable que controla la
cancelaci�n, no necesita ser la variable del objeto, de forma que un
objetoAjax podr�a cancelar a otro diferente. */
function objetoAjaxHtml(ruta,idDondeInsertar,nombreVariable,damarece) {
	this.ruta = ruta; //Ruta que llega asta el archivo con su nombre y extensi�n.
	this.id = idDondeInsertar; //El campo donde insertar.
	this.nombreVariable = nombreVariable; //Nombre de esta variable para poner el cuadro de carga.
	this.damarece = damarece; //Nombre de esta variable para poner el cuadro de carga.
}

function cogerXML(tam_indicadores) {
	var idActual = this.id ; //Dentro de las funciones el this. no funcionar�.
	this.completado = function(estado, estadoTexto, respuestaTexto,respuestaXML)
						{
							//procesarXML(respuestaXML,idActual,tam_indicadores);
							if(window.ActiveXObject){ // If IE Windows
								var XMLdoc = new ActiveXObject("Microsoft.XMLDOM");
								XMLdoc.loadXML(respuestaTexto);
							} else {
								var XMLdoc = respuestaXML;
							} 
							procesarXML(XMLdoc,idActual,tam_indicadores,this.damarece);
							//document.getElementById(idActual).innerHTML = respuestaXML;
						}
	if (this.nombreVariable) //Sin nombre no hay cuadro, lo mostramos antes de empezar la petici�n.
	{
		this.cuadroEstadoCarga(tam_indicadores,this.damarece); /*Sacamos un icono de carga que hipnotiza al usuario, de estas manera tardar� mas en desesperar. */
	}
	this.coger(this.ruta); /* Si alguien ha llamado a la funci�n cogerXML lanzamos la petici�n xmlhttprequest. */
}

var notWhitespace = /\S/;
function cleanWhitespace(node) {
  for (var x = 0; x < node.childNodes.length; x++) {
    var childNode = node.childNodes[x]
    if ((childNode.nodeType == 3)&&(!notWhitespace.test(childNode.nodeValue))) {
// that is, if it's a whitespace text node
      node.removeChild(node.childNodes[x])
      x--
    }
    if (childNode.nodeType == 1) {
// elements can have text child nodes of their own
      cleanWhitespace(childNode)
    }
  }
}

function procesarXML(respuestaXML,idActual,tam_indicadores,damarece)
{
			 	  var respuesta = "";
				  var documento_xml = respuestaXML;
				  var root = documento_xml.getElementsByTagName("indicadores")[0];

			if(root!=null){
				var indicadores = root.getElementsByTagName("indicador");
			if(indicadores!=null){
			if(indicadores.length>0){
var num_items=4;
if(tam_indicadores==1){
	respuesta+="<div class=\"contenido\">\n";
	respuesta+="<h2 class=\"tit_conten\">Coyuntura econ&oacute;mica de Canarias</h2>\n";
	respuesta+="<div class=\"bloque\">\n";
	respuesta+="<p>\n";
	respuesta+="Los indicadores de coyuntura describen la evoluci&oacute;n de la econom&iacute;a a corto plazo, permitiendo analizar el crecimiento, estancamiento o retroceso de sus componentes.\n";
	respuesta+="</p>\n";
	respuesta+="<div class=\"gap\">\n";
	respuesta+="</div>\n";
	respuesta+="<table class=\"tabla_indicadores\" summary=\"Indicadores de coyuntura econ&oacute;mica de Canarias\">\n";
		respuesta+="<thead>\n";
			respuesta+="<tr class=\"alder\">\n";
				respuesta+="<th class=\"alizq\" scope=\"col\" style=\"width:200px;\">Indicador</th>\n";
				respuesta+="<th class=\"alcen\" scope=\"col\" style=\"width:50px;\">Dato</th>\n";
				respuesta+="<th class=\"alder\" scope=\"col\" style=\"width:125px;\">Variaci&oacute;n anual (%)</th>\n";
			respuesta+="</tr>\n";
		respuesta+="</thead>\n";
	respuesta+="</table>\n";
	respuesta+="<input type='hidden' id='current_page' value='0'/>  \n";
	respuesta+="<input type='hidden' id='show_per_page' value='"+num_items+"'/>  \n";
	respuesta+="<div id=\"content_tabla\">\n";
}else{
	respuesta+="<div class=\"fondo_columnas\">\n";
	respuesta+="<h2 class=\"tit_azul\">Coyuntura econ&oacute;mica</h2>\n";
	respuesta+="<div class=\"bordes_columnas\">\n";
	respuesta+="<input type='hidden' id='current_page' value='0'/>  \n";
	respuesta+="<input type='hidden' id='show_per_page' value='"+num_items+"'/>  \n";
	respuesta+="<div id=\"content_indicadores\">\n";
	respuesta+="<ul id=\"menu_indicadores\">\n";
}
				  for (var i = 0; i < indicadores.length; i++)
				  {
			 
					  var ultimo_valor = indicadores[i].getElementsByTagName("ultimo_valor")[0].firstChild.nodeValue;
					  var fecha = indicadores[i].getElementsByTagName("fecha")[0].firstChild.nodeValue;
					  if(indicadores[i].getElementsByTagName("tasa")[0].firstChild==null)var tasa="";
					  else tasa=indicadores[i].getElementsByTagName("tasa")[0].firstChild.nodeValue;
					  var nombre = indicadores[i].getElementsByTagName("nombre")[0].firstChild.nodeValue;
					  var unidad = indicadores[i].getElementsByTagName("unidad")[0].firstChild.nodeValue;
					  var visualizar = indicadores[i].getElementsByTagName("visualizar")[0].firstChild.nodeValue;
					  //respuesta+= "ultimo_valor = " + ultimo_valor + "<br/>" + "fecha = " + fecha + "<br/>" + "tasa = " + tasa + "<br/>" + "nombre = " + nombre + "<br/>" + "unidad = " + unidad;
if(tam_indicadores==1){
if(i<num_items) respuesta+="<div class=\"indicador\">";
else respuesta+="<div class=\"indicador\" style=\"display:none;\">\n";
	respuesta+="<table class=\"tabla_indicadores\" summary=\"Indicadores de coyuntura econ�mica de Canarias\">\n";
	if (i%2==1)
			respuesta+="<tr class=\"nobanda alder\">\n";
	if (i%2==0)
			respuesta+="<tr class=\"banda alder\">\n";
	
				respuesta+="<td class=\"cabfila alizq\" scope=\"row\" style=\"margin: 0; padding-bottom: 0;padding-top: 3px; width:200px;\">\n";
				respuesta+="<div style=\"margin: 0; padding: 0; border-color: #C4D0DC; border-width: thin;\" title=\" " + nombre + "\">\n";
					if(nombre.length>35)
						respuesta+=nombre.substring(0,36)+"...\n";
					else
						respuesta+=nombre+"\n";
				respuesta+="</div>\n";
				respuesta+="</td>\n";
				respuesta+="<td rowspan=\"2\" style=\"width:50px;\">\n";
					respuesta+=ultimo_valor +"\n";
				respuesta+="</td>\n";
				respuesta+="<td rowspan=\"2\" style=\"width:125px;\">\n";
					respuesta+=tasa+"\n";
				respuesta+="</td>\n";

	if (i%2==1)
			respuesta+="<tr class=\"alder\">\n";
	if (i%2==0)
			respuesta+="<tr class=\"banda alder\">\n";
				respuesta+="<td class=\"alizq\" scope=\"row\" style=\"margin: 0; padding-bottom: 3px;padding-top: 0;\">\n";
			respuesta+="<div class=\"gris indicador indicador_central\">\n";
					respuesta+=fecha +" - "+unidad+"\n";
			respuesta+="</div>\n";
				respuesta+="</td>\n";
			respuesta+="</tr>\n";
	respuesta+="</table>\n";
	respuesta+="</div>\n";
}else{
if(i<num_items) respuesta+="<div class=\"indicador\">";
else respuesta+="<div class=\"indicador\" style=\"display:none;\">\n";
			respuesta+="<li>\n";

			respuesta+="<div style=\"margin: 0; padding: 0; border-color: #C4D0DC; border-bottom-style: dotted; border-width: thin; \" title=\""+nombre+"\"><b>\n";
				if(nombre.length>67)
					respuesta+=nombre.substring(0,68)+"...\n";
				else
					respuesta+=nombre+"\n";			
			respuesta+="</b><br />\n";
			respuesta+="</div>\n";
			respuesta+="<div class=\"gris indicador indicador_lateral\">\n";
			respuesta+=fecha+" -\n";
			if(visualizar.trim()!="tasa")
				respuesta+=unidad;
			else
				 respuesta+="Variaci&oacute;n anual (%)\n";
			respuesta+="</div>\n";
			respuesta+="<div style=\"text-align: right; font-size: large;font: Arial,Helvetica,sans-serif;\">\n";
				respuesta+="<b>\n";
			if(visualizar.trim()!="tasa")
				respuesta+=ultimo_valor;
			else
				respuesta+=tasa;
			respuesta+="</b>\n";
			respuesta+="</div>\n";
			respuesta+="</li>\n";
			
	respuesta+="</div>\n";
}
				  }
if(tam_indicadores==1){				  

	respuesta+="</div>\n";


	respuesta+="<script type=\"text/javascript\" src=\"jquery.js\"></script>\n";
	respuesta+="<div class=\"gap\">\n";
	respuesta+="</div>\n";
	respuesta+="<a class=\"dif\" target=\"_blank\" href=\""+damarece+"\">Todos los indicadores</a>\n";
	var pag=indicadores.length/num_items;
	if(indicadores.length>num_items){
		respuesta+="<div id=\"page_navigation\"><div><a class=\"page_link active_page\" href=\"javascript:go_to_page(0)\" longdesc=\"0\">1</a>\n";
		for(var x=1;x<pag;x++){
			respuesta+="<a class=\"page_link\" href=\"javascript:go_to_page("+x+")\" longdesc=\""+x+"\">"+(x+1)+"</a>\n";
		}
		respuesta+="</div></div> \n";
	}
	respuesta+="<br/>\n";
	respuesta+="<br/>\n";
	respuesta+="<br/>\n";
  
  
	respuesta+="</div>\n";
	respuesta+="</div>\n";
}else{
	respuesta+="</ul>\n";
	respuesta+="<script type=\"text/javascript\" src=\"jquery.js\"></script>\n";
	respuesta+="<div class=\"gap\">\n";
	respuesta+="</div>\n";
	respuesta+="<a class=\"dif\" target=\"_blank\" href=\""+damarece+"\">Todos los indicadores</a>\n";
	var pag=indicadores.length/num_items;
	if(indicadores.length>num_items){
		respuesta+="<div id=\"page_navigation\"><a class=\"page_link active_page\" href=\"javascript:go_to_page_lateral(0)\" longdesc=\"0\">1</a>\n";
		for(var x=1;x<pag;x++){
			respuesta+="<a class=\"page_link\" href=\"javascript:go_to_page_lateral("+x+")\" longdesc=\""+x+"\">"+(x+1)+"</a>\n";
		}
		respuesta+="</div> \n";
	}
	respuesta+="</div>\n";
	
  
  
	respuesta+="</div>\n";
	respuesta+="</div>\n";
}
				  }
				  }
				  }
				  document.getElementById(idActual).innerHTML = respuesta;
}

function cuadroEstadoCarga(tam_indicadores,damarece)
{
	var respuesta = "";
	//Mostramos un cuadrito de carga en el lugar donde ir� lo que estamos cargando.
	if(tam_indicadores==1){
		respuesta+="<div class=\"contenido\">\n";
		respuesta+="<h2 class=\"tit_conten\">Coyuntura econ&oacute;mica de Canarias</h2>\n";
		respuesta+="<div class=\"bloque\">\n";
		respuesta+="<div class=\"gap\">\n";
		respuesta+="</div>\n";
	}else{
		respuesta+="<div class=\"fondo_columnas\">\n";
		respuesta+="<h2 class=\"tit_azul\">Coyuntura econ&oacute;mica</h2>\n";
		respuesta+="<div class=\"bordes_columnas\">\n";
		respuesta+="<div id=\"content_indicadores\">\n";
		respuesta+="<ul id=\"menu_indicadores\">\n";
	}
	respuesta+="<center>" + "<img src=\"/istac/galerias/imagenes/ajax-loader.gif\" alt=\"Cargando\" width=\"16\" height=\"16\" />" + "</center>";
if(tam_indicadores==1){				  
	respuesta+="<div class=\"gap\">\n";
	respuesta+="</div>\n";
	respuesta+="<a class=\"dif\" target=\"_blank\" href=\""+damarece+"\">Todos los indicadores</a>\n";
	respuesta+="</div></div> \n";
	respuesta+="<br/>\n";
	respuesta+="<br/>\n";
	respuesta+="<br/>\n";
}else{
	respuesta+="</ul>\n";
	respuesta+="<div class=\"gap\">\n";
	respuesta+="</div>\n";
	respuesta+="<a class=\"dif\" target=\"_blank\" href=\""+damarece+"\">Todos los indicadores</a>\n";
	respuesta+="</div>\n";
	
  
  
	respuesta+="</div>\n";
	respuesta+="</div>\n";
}	
	document.getElementById(this.id).innerHTML = respuesta;
}

//Esta nueva clase hereda como prototipo la ClasePeticionAjax
objetoAjaxHtml.prototype = new objetoAjax;
//Definimos las funciones nuevas pertenecientes al objeto Html en particular.
objetoAjaxHtml.prototype.cogerXML = cogerXML; //Le a�adimos la funci�n cogerXML.
objetoAjaxHtml.prototype.cuadroEstadoCarga = cuadroEstadoCarga; /* El cuadro que indica el estado de la carga. */

String.prototype.trim = function() {
    return this.replace(/^\s+|\s+$/g,"");
}